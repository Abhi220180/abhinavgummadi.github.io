# Abhinav Gummadi — Basic Website (GitHub Pages)

This repo is ready for GitHub Pages.

## Deploy
1. Create a **public** repo named **Abhi220180.github.io** on GitHub.
2. Upload `index.html` (this file is enough).
3. In the repo, open **Settings → Pages**, set **Source: Deploy from a branch**, branch **main**, folder **/**.
4. Open https://Abhi220180.github.io

## Customize
- Edit text in `index.html`.
- Add more sections (skills, resume, blog) as needed.
